#!/usr/bin/env bash
gsutil cors set cors-config.json  gs://asrevo-ts/
